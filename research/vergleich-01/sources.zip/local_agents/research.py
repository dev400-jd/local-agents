"""Gepaarter Ollama-Vergleich auf den versionierten Agentenfällen."""
import argparse
import hashlib
import json
import os
import platform
import random
import sqlite3
import subprocess
import sys
import time
from datetime import datetime, timezone
from importlib.metadata import version
from pathlib import Path
from urllib.request import urlopen

from local_agents.agent import MODEL_SETTINGS, OLLAMA_BASE_URL, OUTPUT_MODE, ollama_model
from local_agents.evals import AGENTS, REPO_CASES, code_state, load_cases

ROOT = REPO_CASES.parent


def api(path):
    with urlopen(OLLAMA_BASE_URL.removesuffix("/").removesuffix("/v1") + path, timeout=10) as response:
        return json.load(response)


def plan(args, cases):
    rng = random.Random(args.seed)
    selected = {}
    for agent in sorted(args.agent or cases):
        if AGENTS[agent].uses_model:
            names = sorted(case.name for case in cases[agent])
            selected[agent] = rng.sample(names, min(args.cases or len(names), len(names)))
    blocks = []
    order = rng.sample(args.models, 2)
    for rep in range(args.repeats):
        tasks = [(agent, name) for agent, names in selected.items() for name in names]
        rng.shuffle(tasks)
        for model in order[::1 if rep % 2 == 0 else -1]:
            blocks.extend([rep + 1, model, agent, name] for agent, name in tasks)
    return blocks


def fingerprint():
    digest = hashlib.sha256()
    paths = sorted(REPO_CASES.rglob("*")) + sorted((ROOT / "local_agents").glob("*.py"))
    paths += sorted((ROOT / "tests/data").glob("*"))
    for path in paths:
        if path.is_file() and path.name != "research_report.py":
            digest.update(str(path.relative_to(ROOT)).encode() + b"\0" + hashlib.sha256(path.read_bytes()).digest())
    return digest.hexdigest()


def trial(model, agent, name):
    case = next(c for c in load_cases([REPO_CASES])[agent] if c.name == name)
    suite = AGENTS[agent]
    start = time.monotonic()
    report = suite.dataset_type(name=agent, cases=[case]).evaluate_sync(
        suite.task(ollama_model(model)), progress=False, max_concurrency=1
    )
    seconds = time.monotonic() - start
    if report.failures:
        message = report.failures[0].error_message
        status = "model_error" if "UnexpectedModelBehavior" in message else "execution_error"
        return dict(status=status, detail=message[:1200], seconds=seconds)
    run, = report.cases
    checks = {key: dict(pass_check=a.value, reason=a.reason) for key, a in run.assertions.items()}
    errors = [f.error_message for f in run.evaluator_failures]
    status = "pass" if checks and all(c["pass_check"] for c in checks.values()) else "fail"
    return dict(status="grader_error" if errors or not checks else status, checks=checks,
                errors=errors, output=run.output.model_dump(mode="json"), seconds=seconds)


def measure(args):
    blocks = plan(args, load_cases([REPO_CASES]))
    models = {m["name"]: m for m in api("/api/tags")["models"]}
    missing = set(args.models) - models.keys()
    if missing:
        raise SystemExit(f"Modell fehlt in Ollama: {sorted(missing)}")
    protocol = dict(schema=1, schedule=blocks, seed=args.seed, fingerprint=fingerprint(),
                    models={m: models[m] for m in args.models}, baseline=args.models[0],
                    endpoint=OLLAMA_BASE_URL, ollama=api("/api/version"), output=OUTPUT_MODE,
                    settings=MODEL_SETTINGS, platform=platform.platform(), python=platform.python_version(),
                    dependencies={p: version(p) for p in ("pydantic-ai-slim", "pydantic-evals", "openai")},
                    timeouts={a: AGENTS[a].timeout for _, _, a, _ in blocks})
    args.out.mkdir(parents=True, exist_ok=True)
    lock = (args.out / "run.lock").open("a")
    import fcntl
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    with sqlite3.connect(args.out / "run.sqlite") as db:
        db.execute("CREATE TABLE IF NOT EXISTS protocol (config TEXT, started TEXT, revision TEXT)")
        db.execute("CREATE TABLE IF NOT EXISTS trials (id INTEGER PRIMARY KEY, result TEXT)")
        existing = db.execute("SELECT config FROM protocol").fetchone()
        if existing and json.loads(existing[0]) != protocol:
            raise SystemExit("Protokoll geändert. Bitte neues Ausgabeverzeichnis verwenden.")
        if not existing:
            db.execute("INSERT INTO protocol VALUES (?,?,?)", (json.dumps(protocol), datetime.now(timezone.utc).isoformat(), code_state()))
            db.commit()
        for i, (_, model, agent, name) in enumerate(blocks):
            if db.execute("SELECT 1 FROM trials WHERE id=?", (i,)).fetchone():
                continue
            # Eigener Prozess begrenzt auch blockierende synchrone Agentenaufrufe.
            deadline = AGENTS[agent].timeout
            try:
                proc = subprocess.run([sys.executable, "-m", "local_agents.research", "_trial", model, agent, name],
                                      cwd=ROOT, capture_output=True, text=True, timeout=deadline)
                proc.check_returncode()
                result = json.loads(proc.stdout.splitlines()[-1])
            except subprocess.TimeoutExpired:
                result = dict(status="timeout", seconds=deadline)
            db.execute("INSERT INTO trials VALUES (?,?)", (i, json.dumps(result, ensure_ascii=False)))
            db.commit()
            print(f"{i+1}/{len(blocks)} {model} {agent} · {name} · {result['status']} ({result['seconds']:.1f}s)", flush=True)


def main():
    if sys.argv[1:2] == ["_trial"]:
        print(json.dumps(trial(*sys.argv[2:]), ensure_ascii=False))
        return
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("models", nargs=2, metavar="MODELL")
    parser.add_argument("--out", required=True, type=Path)
    parser.add_argument("--agent", nargs="+", choices=[a for a in AGENTS if AGENTS[a].uses_model])
    parser.add_argument("--cases", type=int, help="Zufallsstichprobe je Disziplin (Standard: alle)")
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--seed", type=int, default=20261128)
    args = parser.parse_args()
    if len(set(args.models)) != 2 or args.repeats < 1 or (args.cases is not None and args.cases < 1):
        parser.error("Zwei verschiedene Modelle und positive Fall- und Laufzahlen erforderlich")
    measure(args)


if __name__ == "__main__":
    main()
